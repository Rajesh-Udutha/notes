<?php

/**
 * This is the model class for table "attributes".
 *
 * The followings are the available columns in table 'attributes':
 * @property integer $id
 * @property integer $document_id
 * @property string $title
 * @property string $owner
 * @property string $version
 * @property string $createdDate
 * @property string $subject
 * @property string $modifiedDate
 * 
 *
 * The followings are the available model relations:
 * @property Documents $document
 */
class Attributes extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
    public $path;
	public function tableName()
	{
		return 'attributes';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		if(isset($_POST['saveDocument']))
		{
		    return array(
		      //  array('document_id', 'required'),
		       // array('document_id', 'numerical', 'integerOnly'=>true),
		        array('title', 'required'),
		        array('owner', 'required'),
		        array('version', 'required'),
		        array('subject', 'required'),
		        array('path', 'validatePath'),
		        array('title, owner, version, subject', 'length', 'max'=>500),
		        array('createdDate, modifiedDate, path', 'safe'),
		        // The following rule is used by search().
		        // @todo Please remove those attributes that should not be searched.
		        array('id, document_id, title, owner, version, createdDate, subject, modifiedDate', 'safe', 'on'=>'search'),
		    );
		}
		else{
    		return array(
    			array('document_id', 'required'),
    			array('document_id', 'numerical', 'integerOnly'=>true),
    			array('title, owner, version, subject', 'length', 'max'=>500),
    			array('createdDate, modifiedDate, path', 'safe'),
    			// The following rule is used by search().
    			// @todo Please remove those attributes that should not be searched.
    			array('id, document_id, title, owner, version, createdDate, subject, modifiedDate', 'safe', 'on'=>'search'),
    		);
		}
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'document' => array(self::BELONGS_TO, 'Documents', 'document_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'document_id' => 'Document',
			'title' => 'Title',
			'owner' => 'Owner',
			'version' => 'Version',
			'createdDate' => 'Created Date',
			'subject' => 'Subject',
			'modifiedDate' => 'Modified Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('document_id',$this->document_id);
		$criteria->compare('title',$this->title,true);
		$criteria->compare('owner',$this->owner,true);
		$criteria->compare('version',$this->version,true);
		$criteria->compare('createdDate',$this->createdDate,true);
		$criteria->compare('subject',$this->subject,true);
		$criteria->compare('modifiedDate',$this->modifiedDate,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Attributes the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	
	public function validatePath($attribute,$params)
	{
	    $data = CUploadedFile::getInstance($this,'path');
	    if(($data == null || $data==''))
	    {
	        $this->addError($attribute, Yii::t('message', 'Please upload file'));
	    }
	}
	
	
	protected function beforeSave()
	{
	    
	    
	    
	    
	    
	    if ($this->isNewRecord){
	        
	        $this->createdDate = date("Y-m-d H:i:s");
	        
	        //$this->CreatedBy=Yii::app()->user->Id;
	    }	else{
	        $this->modifiedDate = date("Y-m-d H:i:s");
	       // $this->ModifiedBy=Yii::app()->user->Id;
	    }
	    
	    
	    return parent::beforeSave();
	}
	
}
