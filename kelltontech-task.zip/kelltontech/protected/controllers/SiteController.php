<?php


Yii::import('zii.widgets.grid.CGridView');
include 'class.pdf2text.php';

// Yii::import('ext.phpexcel.PHPExcel');

error_reporting(E_ALL & ~ E_NOTICE);
ini_set('display_errors', 'on');

class SiteController extends Controller
{

    // public $layout='//layouts/regLayout';
    
    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     *
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array(
                'allow', // allow all users to perform 'index' and 'view' actions
                'actions' => array(
                    'index','program','addFile','searchFile','getFileData'
                 
                ),
                'users' => array(
                    '*'
                )
            ),
            array(
                'allow', // allow authenticated user to perform 'create' and 'update' actions
                'actions' => array(
              
                    'logout'
                ),
                // 'users'=>array('*'),
                'users' => array(
                    '@'
                )
            ),
            array(
                'allow', // allow admin user to perform 'admin' and 'delete' actions
                'actions' => array(
                    'admin',
                    'delete'
                ),
                'users' => array(
                    'admin'
                )
            ),
            array(
                'deny', // deny all users
                'users' => array(
                    '*'
                )
            )
        );
    }

    /**
     * Declares class-based actions.
     */
    public function actions()
    {
        return array(
            // captcha action renders the CAPTCHA image displayed on the contact page
            'captcha' => array(
                'class' => 'CCaptchaAction',
                'backColor' => 0xF8F8F8,
                'foreColor' => 0x000000
            ),
            // page action renders "static" pages stored under 'protected/views/site/pages'
            // They can be accessed via: index.php?r=site/page&view=FileName
            'page' => array(
                'class' => 'CViewAction'
            )
        );
    }

    /**
     * This is the default 'index' action that is invoked
     * when an action is not explicitly requested by users.
     */
    public function actionReportlist()
    {
        $this->render('reportlist');
    }



    public function actionIndex()
    {
        
        $sql = "select * from documents";
        $dataProvider = new CSqlDataProvider($sql,array("pagination"=>array("pageSize"=>10)));
            $this->render('index',array("model"=>$dataProvider));
    }
    public function actionError()
    {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest)
                echo $error['message'];
                else
                    $this->render('error', $error);
        }
    }
    public function actionAddFile()
    {
        $model = new Attributes();
        if(isset($_POST['Attributes']))
        {
           
            $model->attributes = $_POST['Attributes'];
            if($model->validate())
            {
                $model->path = CUploadedFile::getInstance($model, "path");
                $model->path->saveAs("Documents/".$model->path,true);
                
                $docModel = new Documents();
                $docModel->path = "Documents/".$model->path;
                $docModel->name = $model->path->name;
                $docModel->size = $model->path->size;
                $docModel->type = $model->path->getExtensionName();
                $docModel->save();
                
                $model->document_id = $docModel->id;
                $model->save();
                Yii::app()->user->setFlash('message', Yii::t('message', 'File uploaded successfully.'));
                $this->redirect(array('index'));
            }
            else{
                
            }
        }
        $this->render("documents",array("model"=>$model));
    }

    public function actionSearchFile()
    {
        $val = $_POST['val'];
        $criteria = new CDbCriteria();
        if(!empty($val))
        {
            $criteria->addSearchCondition('name', $val,true);
            $comments = Documents::model()->findAll( $criteria );
        
            if(empty($comments))
            {
                $fileArr = array();
                $dataPro = Documents::model()->findAll();
                if(!empty($dataPro))
                {
                    foreach ($dataPro as $documentData)
                    {
                        $filename = $documentData->path;
                       /*  $handle = fopen($filename, "r");;
                        
                        $contents = fread($handle, filesize($filename));
                        
                        fclose($handle);
                         */
                        $a = new PDF2Text();
                        $a->setFilename($filename);
                        $a->decodePDF();
                        $contents= $a->output(); 
                   //     echo $contents;
                        if (stripos($contents,$val) !== false) {
                          array_push($fileArr,$documentData->name);
                     //     print_r($fileArr);
                        }
                    
                    }
                    
                    if(!empty($fileArr))
                    {
                        $criteria2 = new CDbCriteria();
                        $criteria2->addInCondition("name", $fileArr);
                        $comments = Documents::model()->findAll( $criteria2 );
                        
                    }
                }
                
            }
        
        }
        else{
         //   $criteria->addCondition("id=:id",array(":id"=>"-1"));
            $comments = Documents::model()->findAll();
        }
        
        
        
       
        $this->renderPartial("searchData",array("model"=>$comments),false,true);
        
    }
    
    public function actionGetFileData()
    {
        $id = $_POST['fileid'];
        $fileData = Documents::model()->findByPk($id);
        $attributes = Attributes::model()->find("document_id=:did",array(":did"=>$id));
        $this->renderPartial("fileData",array("fileData"=>$fileData,"attributes"=>$attributes),false,true);
    }
    
}