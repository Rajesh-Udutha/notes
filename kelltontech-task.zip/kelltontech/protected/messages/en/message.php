<?php

return array (
		//	LOGIN
		 'USERNAME_REQUIRED' => 'Please enter username.'
		
);

?>