<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <style>
  @import url('https://fonts.googleapis.com/css?family=Amaranth');
  body{
    margin:100px
}
.errorMessage
{
    color:red;
    padding:10px;
}
.requrd-fld
{
    color:red;
    font-size:15px
}
.summary
{
    display:none
}
.grid-view
{
    padding:15px 0
}
*{
	font-family:'Amaranth', sans-serif;
	
	}
  </style>
</head>
<body>
<?php echo $content; ?>
</body>

  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</html>