<div id="grid" class="grid-view">
<table class="table table-striped">
<thead>
	<tr>
		<th>
			S.No.
		</th>
		<th>Name</th>
		<th>Size</th>
		<th>Type</th>
	</tr>
</thead>
<tbody>
	<?php 
	   if(!empty($model))
	   {
	       $i = 0;
	       foreach($model as $data)
	       {
	           $i++;
	           ?>
	           <tr>
	           <td><?php echo $i?></td>
	           <td><a href="javascript:void(0)" onclick="showFileData(<?php echo $data->id?>)"><?php echo $data->name?></a></td>
	           <td><?php echo $data->size."&nbsp;Bytes"?></td>
	           <td><?php echo $data->type?></td>
	           </tr>
	           <?php 
	           
	       }
	   }
	   else{
	       ?>
	       <tr>
	       	<td colspan="4">
	       	No result found..
	       	</td>
	       </tr>
	       <?php 
	   }
	?>
</tbody>
</table></div>
