<title>Add File</title>
<div class="container">
	
	<div class="panel panel-default">
		<div class="panel-heading" style="font-size: 19px">
		<div class="row">
		<div class="col-lg-10">
			Add Document</div>
			<div class="col-lg-2">
			<button type="button" class="btn btn-primary" onclick="js:document.location.href='<?php echo Yii::app()->request->baseUrl?>'" >Back</button>
			</div>
		</div>
		</div>
		<div class="panel-body">
		<div class="row">
					<?php 
					$form=$this->beginWidget('CActiveForm', array(
					    'id'=>'Document-form',
					    'enableAjaxValidation'=>false,
					    'enableClientValidation'=>true,
					    'htmlOptions'=>array('enctype'=>'multipart/form-data',
					        //'onsubmit'=>'return validatedata();',
					        
					        //'onsubmit'=>'return validateEvent()'
					    ),
						));
					
					?>
					<div class="form-group">
				<div class="row">
					<div class="col-lg-4"></div>
					<div class="col-lg-2">Upload File</div>
					<div class="col-lg-3">
					 	<?php echo $form->fileField($model,'path', array('onchange'=>'validateimage()','id'=>'flUpload','style'=>'width:100%')); ?>
	<?php echo $form->error($model,'path'); ?>
					</div>
					<div class="col-lg-3"></div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-lg-4"></div>
					<div class="col-lg-2">Title</div>
					<div class="col-lg-3"><?php echo $form->textField($model,'title',array(
	'size'=>60,'maxlength'=>100,'placeholder'=>'Title','class'=>'form-control',)); ?>
	<?php echo $form->error($model,'title'); ?>
	</div>
					<div class="col-lg-3"></div>
				</div>
				</div>
				<div class="form-group">
				<div class="row">
					<div class="col-lg-4"></div>
					<div class="col-lg-2">Subject</div>
					<div class="col-lg-3"><?php echo $form->textField($model,'subject',array(
	'size'=>60,'maxlength'=>100,'placeholder'=>'Subject','class'=>'form-control',)); ?>
	<?php echo $form->error($model,'subject'); ?>
	</div>
					<div class="col-lg-3"></div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-lg-4"></div>
					<div class="col-lg-2">Owner</div>
					<div class="col-lg-3"><?php echo $form->textField($model,'owner',array(
	'size'=>60,'maxlength'=>100,'placeholder'=>'Owner','class'=>'form-control',)); ?>
	<?php echo $form->error($model,'owner'); ?>
	</div>
					<div class="col-lg-3"></div>
				</div>
				</div>
				
				<div class="form-group">
				<div class="row">
					<div class="col-lg-4"></div>
					<div class="col-lg-2">Version</div>
					<div class="col-lg-3"><?php echo $form->textField($model,'version',array(
	'size'=>60,'maxlength'=>100,'placeholder'=>'Version','class'=>'form-control',)); ?>
	<?php echo $form->error($model,'version'); ?>
	</div>
					<div class="col-lg-3"></div>
				</div>
				</div>
				
				<div class="form-group">
					<div class="row">
					<div class="col-lg-3"></div>
					<div class="col-lg-6" style="text-align:center"><?php echo CHtml::submitButton('Save',
					    array('name' => 'saveDocument','id'=>'saveDocument','class'=>'btn btn-primary','title'=>'Save'));?></div>
				
					<div class="col-lg-3"></div>
				</div>
				</div>
<?php $this->endWidget(); ?>  

		</div>
		</div>
		</div>
		</div>
		
		<script type="text/javascript">

		 function validateimage(){

		       var img = document.getElementById('flUpload');

		       var fileName = img.value;

		       var ext = fileName.substring(fileName.lastIndexOf('.') + 1);



		       if(ext == "pdf" )

		       {

		  

		       }

		       else

		       {

		    	   document.getElementById("flUpload").value = "";   
		           alert("pdf files are allowed","danger");
				
		       }

		     }

		</script>