<title>Index</title>
<div class="container">
	
<center>
<?php if(Yii::app()->user->hasFlash('message')): ?>

	<div class="requrd-fld" style="position: relative;top: -7px">
	
		<?php echo Yii::app()->user->getFlash('message'); ?>
	
	</div>
	<?php endif; ?>
	
</center>
	<div class="panel panel-default">
		<div class="panel-heading"  style="font-size: 19px">
		
			Documents
		</div>
		<div class="panel-body">
		<div class="row">
			<div class="col-lg-8"></div>
			<div class="col-lg-3"><input type="text" class="form-control" name="search" id="search" placeholder="Search" onkeyup="search(this.value)"/></div>
			
			<div class="col-lg-1"><button type="button" class="btn btn-primary" onclick="js:document.location.href='<?php echo Yii::app()->request->baseUrl?>/site/addFile'">Add File</button></div>
			
			
		</div>
		<div id="tbldata">
			<?php 
			$this->widget('zii.widgets.grid.CGridView', array(
			    'dataProvider'=>$model,
			    //'cssFile' => $cssfile,
			    'itemsCssClass'=>'table table-striped',
			    'id'=>'grid',
			    'columns'=>array(
			        
    			         array('header'=>'S.No.',
    			            
    			            'value'=>'++$row',
    			            
    			        ), 
			      
			    array(
			        'id'=>'Name',
			        'header'=>'Name',
			        'value'=>'CHtml::link($data["name"],"javascript:void(0)",array("onclick"=>"showFileData(".$data["id"].")"))',
			        'type'=>'raw',
			        
			    ),
			        array(
			            'id'=>'Size',
			            'header'=>'Size',
			            'value'=>'$data["size"]." ".Bytes',
			            'type'=>'raw',
			            
			        ),
			        array(
			            'id'=>'Type',
			            'header'=>'Document Type',
			            'value'=>'$data["type"]',
			            'type'=>'raw',
			            
			        ),
			        
			    ),
			    ));
			
			?>
			</div>
		</div>
	</div>

</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

    </div>
  </div>
</div>
<script type="text/javascript">
function search(val)
{
	//alert(val)

	$.ajax({

			'url':'<?php echo Yii::app()->request->baseUrl?>/site/searchFile',
			'type':'POST',
			'data':{'val':val},
			'success':function(htmldata)
			{
				$("#tbldata").html("");
				$("#tbldata").html(htmldata.trim());
			}
		

		})
}

function showFileData(fileid)
{
	$.ajax({

		'url':'<?php echo Yii::app()->request->baseUrl?>/site/getFileData',
		'type':'POST',
		'data':{'fileid':fileid},
		'success':function(popupdata)
		{
			$(".modal-content").html(popupdata)
			  $("#exampleModal").modal('show');
		}
	

	})
}
</script>