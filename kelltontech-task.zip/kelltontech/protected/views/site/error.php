<?php
/* @var $this SiteController */
/* @var $error array */
/*
$this->pageTitle=Yii::app()->name . ' - Error';
$this->breadcrumbs=array(
	'Error',
);*/
?>
<style>
#mainmenu,.none,.show,.breadcrumbs,#footer,#progress-bar,.latest-news{display: none;}
body{background: none;}

.error-main{
width: 50%;
margin: auto;
border-top-left-radius: 5px;
border-top-right-radius: 5px;
padding: 0px;
height: auto;
min-height: 50px;
border-right: #999 solid 1px;
border-left: #999 solid 1px;
border-bottom: #999 solid 1px;
margin-top: 10%;
}
.error-text
{
margin:15px;
text-align: center;
font-size: 15px;
}

.error-hdr
{
color: #FF272E;
padding: 5px;
border-top: 1px solid #999;
border-bottom: 1px solid #999;
border-radius: 5px 5px 0px 0px;
height: auto;
min-height: 5px !important;
margin-bottom: 0px;
font-weight: bold;
font-size: 14px;
background: linear-gradient(to bottom, #FFF 0%, #D8D8D8 100%) repeat scroll 0% 0% transparent;
/*d8d8d8*/
}

 

</style>
<div class='error-main'>
<div class="error-hdr">
<span>
 
<h2> <img src="img/alert.png" style="margin-right: 5px;" width="24px" height="24px"><span style="position: relative;bottom: 6px;">Error <?php echo $code; ?></span></h2></span>
</div>
<!-- <h2>Error <?php //echo $code; ?></h2>-->

<div class="error-text">
<?php echo CHtml::encode($message); ?>
</div>
</div>




