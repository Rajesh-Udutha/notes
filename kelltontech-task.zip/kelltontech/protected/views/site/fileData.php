      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"  style="font-size: 19px"><?php echo $attributes->title?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    	<div class="form-group">
    		<div class="row">
    	<div class="col-lg-1"></div>
    			<div class="col-lg-10">
    		
<embed src="<?php echo  Yii::app()->request->baseUrl."/".$fileData->path?>" type="application/<?php echo $fileData->type?>" height="400px" style="width:100%" >
    			</div>
    	<div class="col-lg-1"></div>
    		</div>
    	
    	</div>
    	<div class="form-group">
    		<div class="row">
    		
    			<div class="col-lg-12" ><h4 style="font-size:18px">Document Details</h4></div>
    			
    		</div>
    	</div>
    	<div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Title:</div>
    			<div class="col-lg-4"><?php echo $attributes->title?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    		<div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Owner:</div>
    			<div class="col-lg-4"><?php echo $attributes->owner?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    		<div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Version:</div>
    			<div class="col-lg-4"><?php echo $attributes->version?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    		<div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Size:</div>
    			<div class="col-lg-4"><?php echo $fileData->size." Bytes"?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    		<div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Type:</div>
    			<div class="col-lg-4"><?php echo $fileData->type?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    	
    <div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">Subject:</div>
    			<div class="col-lg-4"><?php echo $attributes->subject?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    	
    	
    		
    <div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">CreateDate:</div>
    			<div class="col-lg-4"><?php echo (!empty($fileData->createdDate))?date("d/m/Y",strtotime($fileData->createdDate)):'';?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    	
    	
    		
    <div class="form-group">
    		<div class="row">
    		<div class="col-lg-3"></div>
    			<div class="col-lg-3">ModifiedDate:</div>
    			<div class="col-lg-4"><?php echo (!empty($fileData->modifiedDate))?date("d/m/Y",strtotime($fileData->modifiedDate)):'';?></div>
    			<div class="col-lg-2"></div>
    		</div>
    	</div>
    	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    
      </div>