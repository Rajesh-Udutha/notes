<?php

class ControllerGenerator extends CCodeGenerator
{
	public $codeModel='gii.generators.controller.ControllerCode';
}