
//$(document).ready(function() {
  //$("#uploadDoc").dialog(
		
var opt=
		 {
				
		height: 'auto',
		width: 'auto',
		autoOpen: false,
		modal: true,
		resizable: false,
		position: {
			 "my": "center bottom " ,      //  Horizontal then vertical, missing values default to center
					"at": "center top+230",     //  Horizontal then vertical, missing values default to center
					"of": window,     //  Element to position against 
					"offset": "20 30",       //  Pixel values for offset, Horizontal then vertical, negative values OK
					"collision": "fit flip", //  What to do in case of 
					"bgiframe": true
		 },
		}
  
  var optt={
	  modal:true,
	  height:1200,
	  width:'80%',
	  resizable:false,
	  autoOpen:false,
	position: {
			 "my": "center bottom " ,      //  Horizontal then vertical, missing values default to center
					"at": "center top+250",     //  Horizontal then vertical, missing values default to center
					"of": window,     //  Element to position against 
					"offset": "20 30",       //  Pixel values for offset, Horizontal then vertical, negative values OK
					"collision": "fit flip", //  What to do in case of 
					"bgiframe": true
		 },
	  buttons : {
		  'Print' : 	function(){$("#download_target").get(0).contentWindow.print();
		  	},
			'Close': function(){
				document.getElementById("download_target").src=""; $(this).dialog("close");
			//	location.reload();
			}
	  }
  };

//});*/

var slideNumber = 0;
function getSlideNo() {
	slideNumber = $('.active').attr('data-slidesjs-item');
	// alert(slideNumber);
	eraseCookie('the_slideno_cookie');
	createCookie('the_slideno_cookie', slideNumber, 1);
	slideNumber = readCookie('the_slideno_cookie'); // => 'the_value'
	// alert(slideNumber);
	// eraseCookie('the_slideno_cookie');
}
function createCookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		var expires = "; expires=" + date.toGMTString();
	} else
		var expires = "";
	document.cookie = name + "=" + value + expires + "; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for ( var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ')
			c = c.substring(1, c.length);
		if (c.indexOf(nameEQ) == 0)
			return c.substring(nameEQ.length, c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name, "", -1);
}

function existingMember(name) {

	if (name == 'Yes') {
		document.getElementById("loginForm").style.display = "block";
		document.getElementById("NewUser").style.display = 'none';

	} else {
		document.getElementById("loginForm").style.display = "none";
		document.getElementById("NewUser").style.display = "block";
	}

}

var whos = null;
function getplaces(gid, src) {

	whos = src;
	// var request =
	// "http://ws.geonames.org/childrenJSON?geonameId="+gid+"&callback=getLocation&style=long";
	var request = "http://www.geonames.org/childrenJSON?geonameId=" + gid
			+ "&callback=listPlaces&style=long";
	aObj = new JSONscriptRequest(request);
	aObj.buildScriptTag();
	aObj.addScriptTag();
}

function listPlaces(jData) {

	counts = jData.geonames.length < jData.totalResultsCount ? jData.geonames.length
			: jData.totalResultsCount;
	who = document.getElementById(whos);
	who.options.length = 0;

	if (counts)
		who.options[who.options.length] = new Option('Select', '');
	else
		who.options[who.options.length] = new Option('No Data Available',
				'NULL');

	for ( var i = 0; i < counts; i++)

		who.options[who.options.length] = new Option(jData.geonames[i].name,
				jData.geonames[i].name);

	delete jData;
	jData = null;
}
function formatphone(val) {
alertr("dsf");
	var len = val.length;
	var newval = "";
	for ( var i = 1; i <= len; i++) {
		if (i == 1 || i == 3 || i == 6) {
			if (i == 1) {
				newval = "(" + val[i - 1];
			} else if (i == 3) {
				newval = newval + val[i - 1] + ")";
			} else if (i == 6) {
				newval = newval + val[i - 1] + "-";
			}

		} else {

			newval = newval + val[i - 1];
		}

	}
	return newval;
}


function masking(input, textbox, e) { 
	//alert('ahhahad')
	if (input.length == 1 || input.length == 4 || input.length == 9) {
		if (e.keyCode != 8) {
			if (input.length == 1) {
				input = '(' + input;
			} else if (input.length == 4) {
				input = input + ')-';
			} else if (input.length == 9) {
				input = input + '-';
			}
		}
		textbox.value = input;
	}
}
function showDialog(obj, fromVal, linkObj) {
	/*alert(obj);
	alert(fromVal);
	alert(linkObj);*/
	if (fromVal == "page") {
		//alert('hiiiiiiiiiiiiiiiiii');
		if (typeof linkObj != 'undefined') {
			linkObj.id = "link";
			linkObj.href = "#link";
		}
		if(obj!=''){
		window.open(obj, "",
				"toolbar=no,   top=200, left=300, width=600, height=600");
		}else{
			jAlert('No information available.');
		}

	} else if (fromVal == "familySumm") {
		//alert('byeeeeeeeeeeeeeee');
		$('#ProgramRegistration_FamilyId').val("45");
		$('#regSummary').dialog('open');
		return false;

	} else {
		//alert('tatatata');
		var res = obj.id.split("-");
		if (res.length > 1) {
			$('#DocumentContentID').val(res[1]);
		} else {
			$('#DocumentContentID').val(obj.id);
		}

		document.getElementById("uploadDialog").style.display = "none";
		document.getElementById("DocumentContent_image").value = "";
		$('#uploadDoc').dialog(opt).dialog('open');
		return false;
	}
}


function showEmailDialog(obj){

	$('#Processingsteps_Id').val(obj.id);
	$('#emailDialog').dialog('open');
	return false;
}
function reviewDocuemnt(obj) {
	document.getElementById("download_target").src = "index.php?r=healthInformation/reviewDocument&documentId="
			+ obj.id;
//	alert(obj.id);
	$('#readDoc').dialog(optt).dialog('open');
	return false;

}
function IsNumeric(input) {
	return (input - 0) == input
			&& (input + '').replace(/^\s+|\s+$/g, "").length > 0;
}


function loadUrl(data) {

       
       
       url = '';
       jQuery.ajax({
              'type' : 'POST',
              'async': false,
              'url' : 'index.php?r=registration/signupinfo',
              'data' : {
                     'signupcode' : data,
                     //'field' : 'signUpUrl'
              },
              'success' : function(html) {
                     url=html.trim();
                     
              
                     return false;
              },
              'cache' : false
       });
       if(url!=''){
              
       window.open(url, "",
       "toolbar=no,   top=200, left=300, width=600, height=600");
}else{
       
       jAlert('No information available.');
}
}




function loadingUrl(data, fromVal) {

	var selID = document.getElementById("SignUpCode_" + data);
	var text = selID.options[selID.selectedIndex].value;
	
	url = '';
	jQuery.ajax({
		'type' : 'POST',
		 'async': false,
		'url' : 'index.php?r=registration/UpdateAjaxDesc',
		'data' : {
			'signupcode' : text,
			'field' : 'signUpUrl'
		},
		'success' : function(html) {
			url=html.trim();
			
		
			return false;
		},
		'cache' : false
	});
	if(url!=''){
		
	window.open(url, "",
	"toolbar=no,   top=200, left=300, width=600, height=600");
}else{
	jAlert('No information available.');
}
}
function isPhoneNumber(input) {
	
	return (input - 0) == input
			&& (input + '').replace(/^[0-9-+]+$/, "").length > 0;
}
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        $('#test').attr('src', e.target.result);
       }
        reader.readAsDataURL(input.files[0]);
       }
    }




function stringStrip()
	{
		//for firstname....
	//	alert('hakjsfd');
		var fname=document.getElementById('Family_HomeAddress1').value;

		var fname1=fname.replace(/^\s+/,"");
		/*fname1 = fname1.toLowerCase().replace(/\b[a-z]/g, function(letter) {
		    return letter.toUpperCase();
		});*/
		ff=document.getElementById('Family_HomeAddress1');
		ff.value=fname1;

		//for middlename....
		var mname=document.getElementById('Family_HomeAddress2').value;

		var mname2=mname.replace(/^\s+/,"");
		/*mname2= mname2.toLowerCase().replace(/\b[a-z]/g, function(letter) {
		    return letter.toUpperCase();
		});*/
		mm=document.getElementById('Family_HomeAddress2');
		mm.value=mname2;

		//for lastname;
		var lname=document.getElementById('Family_HomeAddress3').value;

		var lname1=lname.replace(/^\s+/,"");
		/*lname1=lname1.toLowerCase().replace(/\b[a-z]/g, function(letter) {
		    return letter.toUpperCase();
		});*/
		ll=document.getElementById('Family_HomeAddress3');
		ll.value=lname1;

		//for address one.....
		var addr1=document.getElementById('Family_City').value;

		var addr=addr1.replace(/^\s+/,"");
		/*addr=addr.toLowerCase().replace(/\b[a-z]/g, function(letter) {
		    return letter.toUpperCase();
		});*/
		aa=document.getElementById('Family_City');
		aa.value=addr;

	}

/*
function init() {

	var options = {
			//  types: ['(cities)'],
			  componentRestrictions: {country: "us"}
			 };
    var input1 = document.getElementById('Family_HomeAddress1');
    var autocomplete1 = new google.maps.places.Autocomplete(input1,options);

    var input2 = document.getElementById('Family_HomeAddress2');
    var autocomplete2 = new google.maps.places.Autocomplete(input2,options);

    var input3 = document.getElementById('Family_HomeAddress3');
    var autocomplete3 = new google.maps.places.Autocomplete(input3,options);

    var input4 = document.getElementById('Person_HomeAddress1');
    var autocomplete4 = new google.maps.places.Autocomplete(input4,options);

    var input5 = document.getElementById('Person_HomeAddress2');
    var autocomplete5 = new google.maps.places.Autocomplete(input5,options);

    var input6 = document.getElementById('Person_HomeAddress3');
    var autocomplete6 = new google.maps.places.Autocomplete(input6,options);
    

    
}

google.maps.event.addDomListener(window, 'load', init);
*/




