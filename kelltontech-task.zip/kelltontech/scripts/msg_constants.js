var DEL_CONFIRM_MSG='Are you sure want to delete?';
var EMAIL_SUCC_MSG="Email details have been saved successfully.";
var AUTH_ORDER_ALREADY_EXIST="Authority order entered already exists.";
var ORGANIZATION_REQUIRED="Please enter organization.";
var NO_INVOICE_MSG="There is no invoice available.";
var DOCUMENT_SUCC_MSG="Document has been added successfully.";
//var FILE_SIZE_MSG="File size should be less than 1 MB.";
var FILE_SIZE_MSG="File size should be less than 5 MB.";
var FILE_REQ_MSG="Please select the file.";
var FILE_TYPE_MSG="File type should be PDF, JPG, GIF or PNG.";
var WITHDRAN_MSG="Registration status has been changed to Withdrawn.";
var ACCEPTED_MSG="Registration status has been changed to Accepted.";
var SAVE_ALERT1="Please save the data before proceeding to document review.";
var SAVE_ALERT2="Please save the data before proceeding to the payment step.";
//var SAVE_ALERT3="Please upload the required documents before proceeding to the payment step.";
var SAVE_ALERT3= "Please complete the Health Information & upload Documents as required by guidelines for the program for registered child(ren).";
var REG_DETAILS_SAVE_SUCC="Registration details have been saved successfully.";
var ADJUSTED_AMT_REQUIRED="Please enter adjusted amount.";
var EMAIL_SENT_SUCC="Email has been sent successfully.";
var USER_ID_EXISTS= "User id does not exist.";	
var PHONE_NOT_EXISTS="Home phone or mobile phone does not exist.";
var SAVE_CONFIRM1="You have unsaved data. If you continue, your data may be lost. Are you sure you want to leave this page?";

var SIGNATURE_ALERT2="Please enter electronic signature.";
var NOTIFICATION_MSG="Email notification has been sent successfully.";

var STATUS_CHANGE_MSG="Status has been changed successfully.";
var EMAIL_TEMPLATE_NOT_AVIALABLE="Email template is not available for selected record.";
